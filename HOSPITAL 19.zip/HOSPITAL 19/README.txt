

A community project to ease the negative impact of COVID_19 on the health sector


                    Author: Phillip Gandhi Oloo

                    Phone No.: +254729733660

                    Facebook: /LoveMalaika

                    Email: phillipgoloo@gmail.com

                    Address: Ndwaru road, Riruta, Nairobi, Kenya

                    App Name: Hospital 19

                    Due Date: 15th December, 2021

                    App Version: 0.0.1

                    Submitted to: Google Andela Developer Scholarship 2022


ACKNOWLEDGMENT

I take this Opportunity to acknowledge my Ofafa Jericho High School friends Alex Changara and Andy Blaze
, who introduced me to coding HTML in the year 2006. I also acknowledge Spencer Computer College, where I
began using and practicing MSWord in 2005. I also acknowledge my brother in law who gave me his hard disk
and thereby enabled me do my #GADS2021 Project Phase, 'Building an Album Art Product Page with Angular' 
and afterwards this #GADS2021 community project. I also acknowledge Troy Hunt, who I consider to be a 
close friend, though we;ve never met.

DEDICATION

I dedicate this project to all the young people out there who are making their first steps in coding. I 
want them to know that coding is possible. I once knew nothing but now I know something. I advice them 
to learn about Website Security.

INTRODUCTION

Hospital 19, is an online app that aims to provide important health information to users, link users to 
active local health facilities and reduce overcrowding in Health Centres.

    How it works
1. The user will select the issue they need assistance with
2. They will then choose whether they want to: Talk to an expert, Visit a Clinic, Get more information 
   on the issue or See other related issues

    Notes
1. Adding of Hospitals is semi-manual so that the Hospital or expert can be physically verified
2. The system is made with the bias of working on many devices and circumstances over maximum UI 
3. To GADS2021 is submited the very first version 