from flask import render_template

def aboutStress():
    title = 'Issues Related with Stress'
    issue = 'Stress'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutInjury():
    title = 'Issues Related with Injuries'
    issue = 'Injury'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutSickness():
    title = 'Issues Related with Sickness'
    issue = 'Sickness'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutAbuse():
    title = 'Issues Related with Abuse'
    issue = 'Abuse'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutTeeth():
    title = 'Issues Related with Teeth'
    issue = 'Teeth'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutEyes():
    title = 'Issues Related with Eyes'
    issue = 'Eyes'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutSubstanceAbuse():
    title = 'Issues Related with Substance Or Drug Abuse/ Addiction CLinic'
    issue = 'Substance Abuse'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutTesting():
    title = 'Issues Related with Testing'
    issue = 'Testing'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutCounselling():
    title = 'Issues Related with Counselling'
    issue = 'Counselling'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
def aboutOthopedics():
    title = 'Issues Related with Othopedics'
    issue = 'Othopedics'
    text = ''
    return render_template('SeeRelatedIssues.html',title=title,issue=issue,text=text)
