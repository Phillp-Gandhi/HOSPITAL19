import one

once = one.allinall()
three = one.one
