def allinall():
    savior = 'Jesus'
    one = 1
    two = 2