def homepage():
    description = ''
    keywords = ''
    ogTitle = ''
    homepage ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)
    return homepage

def getAService():
    description = ''
    keywords = ''
    ogTitle = ''
    getService ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return getService

def stress():

  description = ''
  keywords = ''
  ogTitle = ''
  homepage ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)
  return homepage

def injury():
    description = ''
    keywords = ''
    ogTitle = ''
    injury ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return injury

def abuse():
    description = ''
    keywords = ''
    ogTitle = ''
    abuse ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return abuse



def sickness():
    description = ''
    keywords = ''
    ogTitle = ''
    sickness ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return sickness

def tooth():
    description = ''
    keywords = ''
    ogTitle = ''
    tooth ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return tooth

def eyes():
    description = ''
    keywords = ''
    ogTitle = ''
    eyes ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return eyes

def substanceAbuse():
    description = ''
    keywords = ''
    ogTitle = ''
    substanceAbuse ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return substanceAbuse

def testing():
    description = ''
    keywords = ''
    ogTitle = ''
    testing ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return testing

def othopedics():
    description = ''
    keywords = ''
    ogTitle = ''
    othopedics ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return othopedics

def love():
    description = ''
    keywords = ''
    ogTitle = ''
    love ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return love

def counselling():
    description = ''
    keywords = ''
    ogTitle = ''
    counselling ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return counselling

def hospitalRecommendations():
    description = ''
    keywords = ''
    ogTitle = ''
    hospitalRecommendations ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return hospitalRecommendations

def doctorAdvice():
    description = ''
    keywords = ''
    ogTitle = ''
    doctorAdvice ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return doctorAdvice

def visitClinic():
    description = ''
    keywords = ''
    ogTitle = ''
    visitClinic ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return visitClinic

def manyServices():
    description = ''
    keywords = ''
    ogTitle = ''
    manyServices ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

    return manyServices

def appointments():

  description = ''
  keywords = ''
  ogTitle = ''
  appointments ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

  return appointments

def ambulance():
  description = ''
  keywords = ''
  ogTitle = ''
  ambulance ='''
  <meta content="{}" name="description">
  <meta content="{}" name="keywords">
  <meta content= '{}' name='og-title'>'''.format(description,keywords,ogTitle)

  return ambulance