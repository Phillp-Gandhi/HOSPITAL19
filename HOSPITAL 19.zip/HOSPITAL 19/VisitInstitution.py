from flask import render_template



def aboutStress():
    title = 'Visit A Stress and Mental Wellness Clinic'
    issue = 'Stress'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutInjury():
    title = 'Visit A Health Centre for Injury Consultation and Treatment'
    issue = 'Injury'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutSickness():
    title = 'Visit A Health Centre for Sickness Consultation and Treatment'
    issue = 'Sickness'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutAbuse():
    title = 'Visit A Sexual and Gender Based Violence Clinic'
    issue = 'Abuse'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutTeeth():
    title = 'Visit A Dental Clinic'
    issue = 'Teeth'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutEyes():
    title = 'Visit An Optical Clinic'
    issue = 'Eyes'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutSubstanceAbuse():
    title = 'Visit A Substance Or Drug Abuse/ Addiction CLinic'
    issue = 'Substance Abuse'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutTesting():
    title = 'Visit A Health Centre For Various Tests'
    issue = 'Testing'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutCounselling():
    title = 'Visit A Counselling Clinic'
    issue = 'Counselling'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
def aboutOthopedics():
    title = 'Visit An Othopedic Clinic'
    issue = 'Othopedics'
    text = '''------CODE GOES HERE------get location, then populate mental health clinics starting with the nearest'''
    return render_template('VisitInstitution.html',title=title,issue=issue,text=text)
